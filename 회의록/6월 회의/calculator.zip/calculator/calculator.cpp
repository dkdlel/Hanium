#include "stdafx.h"
#define INF 2147438647

int add(int a, int b) {
	return a + b;
}

int substract(int a, int b) {
	return a - b;
}

int multifly(int a, int b) {
	return a * b;
}

int divide(int a, int b) {
	if (b != 0) return a / b;
	return INF;
}