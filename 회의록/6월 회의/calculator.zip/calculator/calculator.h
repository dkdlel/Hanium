#ifndef calculator
#define calculator

int add(int, int);
int substract(int, int);
int multifly(int, int);
int divide(int, int);

#endif