﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// test.rc에서 사용되고 있습니다.
//
#define IDD_TEST_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_START                       1005
#define IDC_EDIT3                       1013
#define IDC_EDIT4                       1014
#define IDC_EDIT1                       1014
#define start_Thread                    1015
#define IDC_EDIT2                       1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
