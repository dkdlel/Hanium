﻿
// testDlg.cpp: 구현 파일
//

#include "stdafx.h"
#include "test.h"
#include "testDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "irprops.lib")
#include <BluetoothAPIs.h>

int state;
BLUETOOTH_DEVICE_INFO m_device_info;
BLUETOOTH_DEVICE_INFO c_device_info;


#include <stdexcept>

#define     THRD_MESSAHE_CONNECT_DEVICE   WM_APP	//첫 기기연결
#define		THRD_MESSAGE_SOMEWORK		  WM_APP + 1 //스크린락	
#define		THRD_MESSAGE_EXIT			  WM_APP + 2 //스크린락 해지
#define     THRD_MESSAGE_NOSIGNAL_DEVICE  WM_APP + 3 //블루투스 꺼져 있음
#define     THRD_MESSAGE_NODEVICE         WM_APP + 4 //연결된 기기 없음
#define     THRD_CLOSE					  WM_APP + 5  //모든쓰레드종료

using namespace std;


int Lock_state = 0;
int MSG_repeat_control = 0;
//0 초기값, 연결되어 있음
//1 연결기기 없음
//2 스크린락 실행(없어서)
//3 스크린락 실행(달라서)
//4 스크린락 해지
//5 블루투스 꺼짐

bool lock_flag = false;
bool bContinue = true;
HANDLE M_Thread;	//모니터링 진입 쓰레드핸들
DWORD m_idThread = 0;	//메인 앱 쓰레드 ID (메세지 전송할 ID)
DWORD bt_idThread = 0;	//블루투스 쓰레드 ID
DWORD WINAPI ThreadProc_BT(LPVOID);

BLUETOOTH_FIND_RADIO_PARAMS m_bt_find_radio = { sizeof(BLUETOOTH_FIND_RADIO_PARAMS) };
BLUETOOTH_DEVICE_SEARCH_PARAMS m_search_params = {
	sizeof(BLUETOOTH_DEVICE_SEARCH_PARAMS),
	1,
	0,
	1,
	1,
	1,
	15,
	NULL
};
BLUETOOTH_DEVICE_INFO S_device_info = { sizeof(BLUETOOTH_DEVICE_INFO), 0, };
BLUETOOTH_DEVICE_INFO C_device_info = { sizeof(BLUETOOTH_DEVICE_INFO), 0, };
BLUETOOTH_RADIO_INFO m_bt_info = { sizeof(BLUETOOTH_RADIO_INFO), 0, };

void checkConn(BLUETOOTH_DEVICE_INFO& master_device, BLUETOOTH_DEVICE_INFO& now_device) {
	printf("메세지 전달 쓰레드 ID : %d\n", m_idThread);

	if (master_device.Address.ullLong == 0) {	//master_device를 아직 정하지 않은 상태
		if (now_device.Address.ullLong != 0) {
			master_device = now_device;
			PostThreadMessage(m_idThread, WM_APP, 0, 0);
			printf("체크문1번(첫 기기연결)\n");
			lock_flag = false;
		}
		else {
			if (MSG_repeat_control != 1) {
				//연결된 기기 없다고 MSG 보내기
				printf("체크문2번(연결된 기기없음)\n");
				PostThreadMessage(m_idThread, WM_APP + 4, 0, 0);
				printf("%d\n", GetLastError());
				MSG_repeat_control = 1;
				lock_flag = false;
			}
		}
	}
	else {	//master_device를 정하고
		if (master_device.Address.ullLong != 0) {	//master_device가 연결 돼 있는데
			if (Lock_state == 1) {	//잠겼을때
				if (master_device.Address.ullLong == now_device.Address.ullLong) {	//now_device가 주소가 같으면
					if (MSG_repeat_control != 4) {
						// 락스크린중지 MSG전송
						//printf("체크문3번(스크린락 해지)\n");
						//PostThreadMessage(m_idThread, WM_APP + 2, 0, 0);
						//Lock_state = 0;
						MSG_repeat_control = 4;
						lock_flag = false;
						return;
					}
				}
			}
			else {	//안 잠겨있을 때
				if (master_device.Address.ullLong != now_device.Address.ullLong) {	//now_device가 주소가 다르면
					if (MSG_repeat_control != 3) {
						//락스크린 실행 MSG 전송
						//printf("체크문4번(스크린락 실행)\n");
						//PostThreadMessage(m_idThread, WM_APP + 1, 0, 0);
						//Lock_state = 1;
						MSG_repeat_control = 3;
						lock_flag = true;
					}
				}
				else {
					MSG_repeat_control = 0;
					lock_flag = false;
					//Lock_state = 0;
					return;
				}
			}
		}
		else {	//master_device가 연결 돼 있지 않을때
			if (Lock_state == 0) {	//지금 안잠겨있는데
				if (now_device.Address.ullLong != 0) {	//now_device가 연결된 것이 있으면
					if (MSG_repeat_control != 2) {
						// 락스크린 실행 MSG 전송
						//printf("체크문5번(스크린락 실행)\n");
						//PostThreadMessage(m_idThread, WM_APP + 1, 0, 0);
						//Lock_state = 1;
						MSG_repeat_control = 2;
						lock_flag = true;
					}
				}
			}
		}
	}
}

#include <iostream>
void bthMain() {		//블루투스 메인함수
	HANDLE m_radio = NULL;
	HBLUETOOTH_RADIO_FIND m_bt = NULL;
	HBLUETOOTH_DEVICE_FIND m_bt_dev = NULL;
	int m_device_id = 0;
	DWORD mbtinfo_ret;

	printf("Btmain접근\n");

	ZeroMemory(&C_device_info, sizeof(BLUETOOTH_DEVICE_INFO));
	C_device_info.dwSize = sizeof(BLUETOOTH_DEVICE_INFO);
	while (bContinue) {
		printf("접근1(radio)\n");
		m_bt = BluetoothFindFirstRadio(&m_bt_find_radio, &m_radio);

		//do {
			if (m_bt == 0) {
				if (MSG_repeat_control != 5) {
					//컴퓨터 블루투스가 꺼진 상황
					PostThreadMessage(m_idThread, WM_APP + 3, 0, 0);
					MSG_repeat_control = 5;
				}
				break;
			}
			// Then get the radio device info....
			mbtinfo_ret = BluetoothGetRadioInfo(m_radio, &m_bt_info);
			m_search_params.hRadio = m_radio;
			ZeroMemory(&S_device_info, sizeof(BLUETOOTH_DEVICE_INFO));
			S_device_info.dwSize = sizeof(BLUETOOTH_DEVICE_INFO);

			// Next for every radio, get the device
			m_bt_dev = BluetoothFindFirstDevice(&m_search_params, &S_device_info);

			m_device_id = 0;
			
			// Get the device info
			do {
				//if ((BluetoothGetDeviceInfo(m_radio, &C_device_info) > 0)
				//	/*|| (BluetoothGetDeviceInfo(m_radio, &C_device_info) == ERROR_REVISION_MISMATCH)
				//	|| (BluetoothGetDeviceInfo(m_radio, &C_device_info) == ERROR_NOT_FOUND)
				//	|| (BluetoothGetDeviceInfo(m_radio, &C_device_info) == ERROR_INVALID_PARAMETER)*/) {
				//	lock_flag = true;
				//	MSG_repeat_control = 2;
				//	break;
				//}
				
				//BluetoothGetDeviceInfo(m_radio, &S_device_info);
				
				
				if (BluetoothGetDeviceInfo(m_radio, &S_device_info) != 0) {
					lock_flag = true;
					MSG_repeat_control = 2;
					break;
				}

				printf("접근2(device)\n");
				checkConn(C_device_info, S_device_info);
				//if (lock_flag == false) break;
				m_device_id++;

			} while (BluetoothFindNextDevice(m_bt_dev, &S_device_info));

			//if (lock_flag = false) break;
		//} while (BluetoothFindNextRadio(&m_bt_find_radio, &m_radio));

		if (lock_flag) {
			if (MSG_repeat_control == 3) {
				printf("체크문4번(스크린락 실행)\n");
				PostThreadMessage(m_idThread, WM_APP + 1, 0, 0);
				Lock_state = 1;
			}
			else {
				printf("체크문5번(스크린락 실행)\n");
				PostThreadMessage(m_idThread, WM_APP + 1, 0, 0);
				Lock_state = 1;
			}
		}
		else {
			if (MSG_repeat_control == 4) {
				printf("체크문3번(스크린락 해지)\n");
				PostThreadMessage(m_idThread, WM_APP + 2, 0, 0);
				Lock_state = 0;
			}
			else if (MSG_repeat_control == 0) {
				printf("master_device 연결 되어있음\n");
				Lock_state = 0;
			}
		}
		// Give some time for the 'signal' which is a typical for crap wireless devices
		Sleep(2000);
	}

}

void stopMon() {  //메인쓰레드에서 호출하는 함수
	printf("stopMon() 함수 실행\n");
	bContinue = false;
}

void startMon() {
	char* M_Thread_Msg = "블루투스 쓰레드 생성완료 "; // 프록시파라미터

	M_Thread = CreateThread(NULL, 0, ThreadProc_BT, (LPVOID)M_Thread_Msg, 0, &bt_idThread);
	WaitForSingleObject(M_Thread, INFINITE);

	bContinue = true;	//stopMon()실행 후 다시 시작하기 위해 flag값 변환
}

void InitMon(DWORD ThreadID) {   //메인쓰레드에서 메인쓰레드ID를 매개변수로 호출하는 함수
	m_idThread = ThreadID;	//받아온 쓰레드 ID 값
	printf("받은 메인쓰레드 ID : %d\n", m_idThread);
	startMon();
}

void UnInitMon() {   //메인스레드에서 호출하는 함수
	printf("UnInitMon()함수 실행\n");
	CloseHandle(M_Thread);  //핸들 닫힘
}



DWORD WINAPI ThreadProc_BT(LPVOID lpParam)
{
	char* TP_Msg = (char*)lpParam; // 프록시로 들어온 파라미터
	printf("%s :: 블루투스 체크 쓰레드 ID: %d\n", TP_Msg, bt_idThread);

	//여기서 이제 블루투스함수진입
	bthMain();

	return (DWORD)lpParam;
}






// CtestDlg 대화 상자


// -------------------------------------------------------------------필요한 부분----------------------------------
// 초기화
CtestDlg::CtestDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TEST_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	n1 = 0;
	n2 = 0;
}

void CtestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}
// -------------------------------------------------------------------필요한 부분----------------------------------
BEGIN_MESSAGE_MAP(CtestDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//--------------------------------------------------------------------
	ON_BN_CLICKED(start_Thread, &CtestDlg::OnBnClickedThread)
	ON_EN_CHANGE(IDC_EDIT1, &CtestDlg::OnEnChangeEdit1)
	ON_EN_CHANGE(IDC_EDIT2, &CtestDlg::OnEnChangeEdit2)
END_MESSAGE_MAP()


// CtestDlg 메시지 처리기

BOOL CtestDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 이 대화 상자의 아이콘을 설정합니다.  응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.

	// TODO: 여기에 추가 초기화 작업을 추가합니다.

	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다.  문서/뷰 모델을 사용하는 MFC 응용 프로그램의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

// -------------------------------------------------------------------필요한 부분----------------------------------
// 함수 정의
void CtestDlg::OnEnChangeEdit1()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CDialogEx::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
void CtestDlg::OnEnChangeEdit2()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CDialogEx::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}

void CtestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 아이콘을 그립니다.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR CtestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


// -------------------------------------------------------------------필요한 부분----------------------------------
// 쓰레드 생성부분
void CtestDlg::OnBnClickedThread()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.

	CWinThread* p = AfxBeginThread(ThreadStart1, this);
	//if (p == NULL)  //쓰레드생성실패시에러메시지
	//	AfxMessageBox(L"thread 1 Error");
	//else CloseHandle(p);
	
	/*CWinThread* p2 = AfxBeginThread(ThreadStart2, this);
	
	if (p2 == NULL) AfxMessageBox(_T("thread 2 error"));
	else CloseHandle(p2);*/
}

// -------------------------------------------------------------------필요한 부분----------------------------------
// 구현부분
UINT CtestDlg::ThreadStart1(LPVOID pParam)
{
	CtestDlg *ptr = (CtestDlg*)pParam;

	/*while (1)
	{
		(ptr->n1)++;

		ptr->plus.Format(L"%d\r\n", ptr->n1);
		ptr->add.Append(ptr->plus);
		ptr->SetDlgItemText(IDC_EDIT1, ptr->add);

		if (ptr->n1%10 == 0)
		{*/
			//DWORD GetCurrentThreadid();
			DWORD dThreadid = GetCurrentThreadId();
			InitMon(dThreadid);

			return 0;
		/*}

		Sleep(1000);
	}

	return 0;*/
}

UINT CtestDlg::ThreadStart2(LPVOID pParam)
{
	CtestDlg *ptr = (CtestDlg*)pParam;

	while (1)
	{
		if(ptr->n2%10 == 0) Sleep(1000);
		else Sleep(2000);

		(ptr->n2)+=2;

		ptr->plus2.Format(L"%d\r\n", ptr->n2);
		ptr->add2.Append(ptr->plus2);
		ptr->SetDlgItemText(IDC_EDIT2, ptr->add2);

		if (ptr->n2 % 10 == 0)
		{
			ptr->plus2.Format(L"10초 끝!!\r\n");
			ptr->add2.Append(ptr->plus2);
			ptr->SetDlgItemTextW(IDC_EDIT2, ptr->add2);

			/*
			DWORD GetCurrentThreadid();
			DWORD dThreadid = GetCurrentThreadId();
			Monitoring::MonitoringFuncs::InitMon(dThreadid);
			*/
			return 0;
		}
	}

	return 0;
}