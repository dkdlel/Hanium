﻿#include "monitoring.h"
using namespace std;

#define     THRD_MESSAHE_CONNECT_DEVICE   WM_APP		//첫 기기연결
#define		THRD_MESSAGE_SOMEWORK		  WM_APP + 1	//락	
#define		THRD_MESSAGE_EXIT			  WM_APP + 2	//언락
#define     THRD_MESSAGE_NOSIGNAL_DEVICE  WM_APP + 3	//블루투스 꺼져있음
#define     THRD_MESSAGE_NODEVICE         WM_APP + 4	//연결된 기기 없음
#define     THRD_CLOSE					  WM_APP + 5	//쓰레드종료
#define		THRD_NOT_FOUND				  WM_APP + 6	//찾는 기기 없음

bool bt_continue;	//모니터링 돌리나
bool select_name;	//master에 이름이 정해졌나
bool running;		//스레드가 생성되어 있는가
int state = 0;
//0 : 첫기기연결
//1 : 락
//2 : 언락
//3 : 블루투스 꺼져있음
//4 : 연결된 기기 없음
//5 : 쓰레드 종료
//6 : 찾는 기기 없음

WCHAR *name;

HANDLE thread;
DWORD main_thread_id;
DWORD bt_thread_id;
DWORD WINAPI bt_proc(LPVOID);

BLUETOOTH_FIND_RADIO_PARAMS find_radio = { sizeof(BLUETOOTH_FIND_RADIO_PARAMS) };
BLUETOOTH_DEVICE_SEARCH_PARAMS search_params = {
	sizeof(BLUETOOTH_DEVICE_SEARCH_PARAMS),
	1,
	0,
	1,
	1,
	1,
	15,
	NULL
};
BLUETOOTH_DEVICE_INFO send_device_info = { sizeof(BLUETOOTH_DEVICE_INFO), 0, };
BLUETOOTH_DEVICE_INFO master_device_info = { sizeof(BLUETOOTH_DEVICE_INFO), 0, };
BLUETOOTH_RADIO_INFO bt_info = { sizeof(BLUETOOTH_RADIO_INFO), 0, };

HANDLE radio = NULL;	//라디오 찾아서 저장되는 위치
HBLUETOOTH_RADIO_FIND radio_handle = NULL;	//라디오 핸들
HBLUETOOTH_DEVICE_FIND device_handle = NULL;	//디바이스 핸들
//int device_id = 0;
DWORD main_bt_info;

void select() {
	enumerate(false);

	if (!select_name) {	//찾기 실패
		state = 6;
		PostThreadMessage(main_thread_id, WM_APP + 6, 0, 0);
	}
}

void init(DWORD thread_id) {
	monitoring::main_thread_id = thread_id;
	printf("받은 메인쓰레드 ID : %d\n", main_thread_id);

	const char* main_thread_msg = "블루투스 쓰레드 생성완료 ";

	bt_continue = true;
	state = 0;

	running = true;
	thread = CreateThread(NULL, 0, bt_proc, (LPVOID)main_thread_msg, 0, &bt_thread_id);
	WaitForSingleObject(thread, INFINITE);
}

DWORD WINAPI bt_proc(LPVOID lpParam)
{
	char* TP_Msg = (char*)lpParam; // 프록시로 들어온 파라미터
	printf("%s :: 블루투스 체크 쓰레드 ID: %d\n", TP_Msg, bt_thread_id);

	//여기서 이제 블루투스함수진입
	bt_main();

	return (DWORD)lpParam;
}

void bt_main() {
	while (bt_continue) {
		enumerate(true);
	}
}

void enumerate(bool check) {	//한번 열거
	printf("radio 접근\n");
	radio_handle = BluetoothFindFirstRadio(&find_radio, &radio);

	do {
		if (radio_handle == NULL) {	//컴퓨터 블루투스 꺼짐
			state = 3;
			PostThreadMessage(main_thread_id, WM_APP + 3, 0, 0);
			return;
		}

		main_bt_info = BluetoothGetRadioInfo(radio, &bt_info);
		search_params.hRadio = radio;
		ZeroMemory(&send_device_info, sizeof(BLUETOOTH_DEVICE_INFO));
		send_device_info.dwSize = sizeof(BLUETOOTH_DEVICE_INFO);

		device_handle = BluetoothFindFirstDevice(&search_params, &send_device_info);
		//device_id = 0;

		do {
			printf("device 접근\n");
			if(check == true) check_connect(master_device_info, send_device_info);
			else if (send_device_info.szName == name) {
				master_device_info = send_device_info;
				select_name = true;

			}
			//device_id++;
		} while (BluetoothFindNextDevice(device_handle, &send_device_info));
	} while (BluetoothFindNextRadio(&find_radio, &radio));

	select_name = false;
}

void check_connect(BLUETOOTH_DEVICE_INFO& master_device, BLUETOOTH_DEVICE_INFO& send_device) {
	printf("메세지 전달 쓰레드 ID : %d\n", main_thread_id);

	if (master_device.Address.ullLong == 0) {	//select 필요
		state = 0;
		PostThreadMessage(main_thread_id, WM_APP, 0, 0);
	}
	else if (send_device.Address.ullLong == 0) {	//연결된 기기 없음
		state = 4;
		PostThreadMessage(main_thread_id, WM_APP + 4, 0, 0);
	}
	else {
		if (state != 1) {	//모니터링이 돌고 있는 경우
			if (master_device.Address.ullLong != send_device.Address.ullLong) {	//락
				state = 1;
				PostThreadMessage(main_thread_id, WM_APP + 1, 0, 0);
				stop();
			}
		}
		else {	//언락
			state = 2;
			PostThreadMessage(main_thread_id, WM_APP + 2, 0, 0);
		}
	}
}

void quit() {
	printf("쓰레드 종료\n");
	state = 5;
	PostThreadMessage(main_thread_id, WM_APP + 5, 0, 0);
	CloseHandle(thread);
	running = false;
}

void stop() {
	printf("모니터링 중지\n");
	bt_continue = false;
}