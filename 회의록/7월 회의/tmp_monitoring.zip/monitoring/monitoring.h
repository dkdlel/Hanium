#ifndef monitoring
#define monitoring

#include <stdio.h>
#include <windows.h>
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "irprops.lib")
#include <BluetoothAPIs.h>

extern int state;
extern BLUETOOTH_FIND_RADIO_PARAMS find_radio;
extern BLUETOOTH_DEVICE_SEARCH_PARAMS search_params;
extern BLUETOOTH_DEVICE_INFO send_device_info;
extern BLUETOOTH_DEVICE_INFO master_device_info;
extern BLUETOOTH_RADIO_INFO bt_info;

class monitoring {
private:
	static void bt_main();
	static void check_connect(BLUETOOTH_DEVICE_INFO&, BLUETOOTH_DEVICE_INFO&);
	static void enumerate(bool);
public:
	static void select();

	static void init(DWORD);

	static void quit();
	
	static void stop();
};

#endif