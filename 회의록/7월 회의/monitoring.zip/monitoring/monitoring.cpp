﻿#include "monitoring.h"
#include <stdexcept>

#define     THRD_MESSAHE_CONNECT_DEVICE   WM_APP		//첫 기기연결
#define		THRD_MESSAGE_SOMEWORK		  WM_APP + 1	//스크린락	
#define		THRD_MESSAGE_EXIT			  WM_APP + 2	//스크린락 해지
#define     THRD_MESSAGE_NOSIGNAL_DEVICE  WM_APP + 3	//블루투스 꺼져 있음
#define     THRD_MESSAGE_NODEVICE         WM_APP + 4	//연결된 기기 없음
#define     THRD_CLOSE					  WM_APP + 5	//모든쓰레드종료
#define		THRD_MESSAGE_NOT_FOUND		  WM_APP + 6	//찾는 기기 없음

using namespace std;

bool lock_state = 0;
int MSG_repeat_control = 0;
bool bt_continue = true;
HANDLE thread;	//모니터링 진입 쓰레드핸들
DWORD main_thread_id = 0;	//메인 앱 쓰레드 ID (메세지 전송할 ID)
DWORD bt_thread_id = 0;	//블루투스 쓰레드 ID
DWORD WINAPI bt_proc(LPVOID);

WCHAR* name;	//찾는 디바이스 이름
bool select_name;	//master에 이름이 정해졌나
bool running;		//스레드가 생성되어 있는가

BLUETOOTH_FIND_RADIO_PARAMS find_radio = { sizeof(BLUETOOTH_FIND_RADIO_PARAMS) };
BLUETOOTH_DEVICE_SEARCH_PARAMS search_param = {
	sizeof(BLUETOOTH_DEVICE_SEARCH_PARAMS),
	1,
	0,
	1,
	1,
	1,
	15,
	NULL
};
BLUETOOTH_DEVICE_INFO send_device_info = { sizeof(BLUETOOTH_DEVICE_INFO), 0, };
BLUETOOTH_DEVICE_INFO master_device_info = { sizeof(BLUETOOTH_DEVICE_INFO), 0, };
BLUETOOTH_RADIO_INFO bt_info = { sizeof(BLUETOOTH_RADIO_INFO), 0, };

//--------------------------------------------------bt_main에 있던 변수들
HANDLE radio = NULL;	//라디오 찾아서 저장
HBLUETOOTH_RADIO_FIND radio_handle = NULL;	//라디오 핸들
HBLUETOOTH_DEVICE_FIND device_handle = NULL;	//디바이스 핸들
int m_device_id = 0;
DWORD main_bt_info;
//----------------------------------------------------------------------

void monitoring::select() {
	printf("radio 접근(select)\n");
	radio_handle = BluetoothFindFirstRadio(&find_radio, &radio);

	do {
		if (radio_handle == 0) {
			if (MSG_repeat_control != 5) {	//컴퓨터 블루투스가 꺼진 상황
				PostThreadMessage(main_thread_id, WM_APP + 3, 0, 0);
				MSG_repeat_control = 5;
			}
			break;
		}

		main_bt_info = BluetoothGetRadioInfo(radio, &bt_info);
		search_param.hRadio = radio;
		ZeroMemory(&send_device_info, sizeof(BLUETOOTH_DEVICE_INFO));
		send_device_info.dwSize = sizeof(BLUETOOTH_DEVICE_INFO);

		device_handle = BluetoothFindFirstDevice(&search_param, &send_device_info);

		do
		{
			printf("device 접근(select)\n");
			
			if (send_device_info.szName == name) {
				master_device_info = send_device_info;
				select_name = true;
				PostThreadMessage(main_thread_id, WM_APP, 0, 0);	//내가 원하는 디바이스 선택
			}

		} while (BluetoothFindNextDevice(device_handle, &send_device_info));

	} while (BluetoothFindNextRadio(&find_radio, &radio));

	select_name = false;
	PostThreadMessage(main_thread_id, WM_APP + 6, 0, 0);	//찾지 못함
}

void monitoring::init(DWORD ThreadID) {   //메인쓰레드에서 메인쓰레드ID를 매개변수로 호출하는 함수
	main_thread_id = ThreadID;	//받아온 쓰레드 ID 값
	printf("받은 메인쓰레드 ID : %d\n", main_thread_id);
	start();
}

void monitoring::start() {
	const char* M_Thread_Msg = "블루투스 쓰레드 생성완료 "; // 프록시파라미터

	bt_continue = true;	//stopMon()실행 후 다시 시작하기 위해 flag값 변환
	thread = CreateThread(NULL, 0, bt_proc, (LPVOID)M_Thread_Msg, 0, &bt_thread_id);
	WaitForSingleObject(thread, INFINITE);
}

DWORD WINAPI bt_proc(LPVOID lpParam)
{
	char* TP_Msg = (char*)lpParam; // 프록시로 들어온 파라미터
	printf("%s :: 블루투스 체크 쓰레드 ID: %d\n", TP_Msg, bt_thread_id);

	//여기서 이제 블루투스함수진입
	monitoring::bt_main();

	return (DWORD)lpParam;
}

void monitoring::bt_main() {		//블루투스 메인함수
	printf("bt_main접근\n");
	while (bt_continue)
	{
		printf("radio 접근(main)\n");
		radio_handle = BluetoothFindFirstRadio(&find_radio, &radio);

		do {
			if (radio_handle == 0) {
				if (MSG_repeat_control != 5) {	//컴퓨터 블루투스가 꺼진 상황
					PostThreadMessage(main_thread_id, WM_APP + 3, 0, 0);
					MSG_repeat_control = 5;
				}
				break;
			}

			main_bt_info = BluetoothGetRadioInfo(radio, &bt_info);
			search_param.hRadio = radio;
			ZeroMemory(&send_device_info, sizeof(BLUETOOTH_DEVICE_INFO));
			send_device_info.dwSize = sizeof(BLUETOOTH_DEVICE_INFO);


			device_handle = BluetoothFindFirstDevice(&search_param, &send_device_info);

			m_device_id = 0;

			do
			{
				printf("device 접근(main)\n");
				check_connect(master_device_info, send_device_info);
				m_device_id++;

			} while (BluetoothFindNextDevice(device_handle, &send_device_info));

		} while (BluetoothFindNextRadio(&find_radio, &radio));

		Sleep(5000);	//5초 간격
	}

}

void monitoring::check_connect(BLUETOOTH_DEVICE_INFO& send_device, BLUETOOTH_DEVICE_INFO& master_device) {
	printf("메세지 전달 쓰레드 ID : %d\n", main_thread_id);

	if (master_device.Address.ullLong == 0) {
		if (MSG_repeat_control != 1) {	//연결된 기기 없다고 MSG 보내기, select()가 필요한 경우
			printf("체크문2번(연결된 기기없음)\n");
			PostThreadMessage(main_thread_id, WM_APP + 4, 0, 0);
			printf("%d\n", GetLastError());
			MSG_repeat_control = 1;
		}
	}
	else {
		if (send_device.fConnected) {
			if (lock_state == true) {	//잠겨 있을 때
				if (send_device.Address.ullLong == master_device.Address.ullLong) {	//같으면
					if (MSG_repeat_control != 4) {	//풀어야지
						printf("체크문3번(스크린락 해지)\n");
						PostThreadMessage(main_thread_id, WM_APP + 2, 0, 0);
						lock_state = false;
						MSG_repeat_control = 4;
					}
				}
			}
			else {	//안 잠겨 있는데
				if (send_device.Address.ullLong != master_device.Address.ullLong) {	//다르면
					if (MSG_repeat_control != 3) { //잠가야지
						printf("체크문4번(스크린락 실행)\n");
						PostThreadMessage(main_thread_id, WM_APP + 1, 0, 0);
						lock_state = true;
						MSG_repeat_control = 3;
					}
				}

			}
		}
		else {	//연결이 돼 있는게 없는데
			if (lock_state == false) {	//안 잠겨 있으면
				if (MSG_repeat_control != 2) { //잠가야지
					printf("체크문5번(스크린락 실행)\n");
					PostThreadMessage(main_thread_id, WM_APP + 1, 0, 0);
					lock_state = 1;
					MSG_repeat_control = 2;
				}
			}
		}
	}
}

void monitoring::stop() {  //메인쓰레드에서 호출하는 함수
	printf("stop() 함수 실행\n");
	bt_continue = false;
}

void monitoring::quit() {   //메인스레드에서 호출하는 함수
	printf("quit()함수 실행\n");
	CloseHandle(thread);  //핸들 닫힘
}