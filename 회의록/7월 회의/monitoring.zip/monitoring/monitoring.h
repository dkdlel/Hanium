#pragma once

#include <stdio.h>
#include <windows.h>
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "irprops.lib")
#include <BluetoothAPIs.h>

extern bool lock_state;
extern BLUETOOTH_FIND_RADIO_PARAMS find_radio;
extern BLUETOOTH_DEVICE_SEARCH_PARAMS search_params;
extern BLUETOOTH_DEVICE_INFO send_device_info;
extern BLUETOOTH_DEVICE_INFO master_device_info;
extern BLUETOOTH_RADIO_INFO bt_info;


class monitoring {
private:
	static void start();
	static void check_connect(BLUETOOTH_DEVICE_INFO&, BLUETOOTH_DEVICE_INFO&);
public:
	static void select();
	static void init(DWORD);
	static void bt_main(); //���ξ����忡�� ȣ���� ���� �ʴ´�
	static void stop();
	static void quit();
};