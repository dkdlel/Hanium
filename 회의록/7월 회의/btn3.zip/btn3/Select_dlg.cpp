﻿// Select_dlg.cpp: 구현 파일
//

#include "stdafx.h"
#include "btn3.h"
#include "Select_dlg.h"
#include "afxdialogex.h"


// Select_dlg 대화 상자

IMPLEMENT_DYNAMIC(Select_dlg, CDialogEx)

Select_dlg::Select_dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
{

}

Select_dlg::~Select_dlg()
{
}

void Select_dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(Select_dlg, CDialogEx)
	ON_EN_CHANGE(IDC_EDIT1, &Select_dlg::OnEnChangeEdit1)
END_MESSAGE_MAP()


// Select_dlg 메시지 처리기

CString str;

void Select_dlg::OnEnChangeEdit1()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CDialogEx::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.
	GetDlgItemText(IDC_EDIT1, str);
	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
